/*
 * ResourceManager API connection.
 * Current local setup: public site on :8078, Laravel backend on :8012.
 * Change this one value if the Laravel backend port or route prefix changes.
 */
window.ERUDITE_RESOURCE_API_BASE = 'http://127.0.0.1:8012/api';
