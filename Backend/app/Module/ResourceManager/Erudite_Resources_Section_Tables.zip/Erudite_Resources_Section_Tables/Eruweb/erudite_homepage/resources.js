/* =========================================================
   ERUDITE RESOURCE LIBRARY
   - Sections are discovered from both resource tables.
   - Video and document records are fetched independently.
   - Every discovered section gets its own table card.
   - Empty data arrays still render the table headers + empty row.
   - Video and document search states are completely independent.
   ========================================================= */
(() => {
  'use strict';

  const configuredBase = window.ERUDITE_RESOURCE_API_BASE || 'http://127.0.0.1:8012/api';
  const API_BASE = String(configuredBase).replace(/\/+$/, '');
  const API_URL = new URL(API_BASE, window.location.href);
  const SECTION_ENDPOINT = `${API_BASE}/resources/sections`;

  const typeConfig = {
    videos: {
      table: 'video_resources',
      endpoint: (section) => `${API_BASE}/resources/video-resources/${encodeURIComponent(section)}`,
      panelId: 'video-resource-panel',
      groupsId: 'video-resource-groups',
      countsId: 'video-resource-counts',
      searchFormId: 'video-resource-search-form',
      searchInputId: 'video-resource-search-input',
      searchClearId: 'video-resource-search-clear',
      searchHintId: 'video-resource-search-hint',
      title: 'Video resources',
      itemLabel: 'video',
      emptyMessage: 'No video resources are available in this section yet.',
      loadMessage: 'Loading video resources…',
      columns: ['ID', 'TITLE', 'TITLE DESCRIPTION', 'YOUTUBE LINK', 'CREATED', 'UPDATED']
    },
    documents: {
      table: 'document_resources',
      endpoint: (section) => `${API_BASE}/resources/document-resources/${encodeURIComponent(section)}`,
      panelId: 'document-resource-panel',
      groupsId: 'document-resource-groups',
      countsId: 'document-resource-counts',
      searchFormId: 'document-resource-search-form',
      searchInputId: 'document-resource-search-input',
      searchClearId: 'document-resource-search-clear',
      searchHintId: 'document-resource-search-hint',
      title: 'Document resources',
      itemLabel: 'document',
      emptyMessage: 'No documents are available in this section yet.',
      loadMessage: 'Select Document Resources to load documents.',
      columns: ['ID', 'TITLE', 'TITLE DESCRIPTION', 'DOCUMENT', 'CREATED', 'UPDATED']
    }
  };

  const typeButtons = [...document.querySelectorAll('[data-resource-type]')];
  const sectionState = { loaded: false, promise: null, data: [] };
  const resourceCache = new Map();
  const states = {};

  for (const [type, config] of Object.entries(typeConfig)) {
    const panel = document.getElementById(config.panelId);
    const groups = document.getElementById(config.groupsId);
    const counts = document.getElementById(config.countsId);
    const searchForm = document.getElementById(config.searchFormId);
    const searchInput = document.getElementById(config.searchInputId);
    const searchClear = document.getElementById(config.searchClearId);
    const searchHint = document.getElementById(config.searchHintId);

    if (!panel || !groups || !counts || !searchForm || !searchInput || !searchClear || !searchHint) {
      console.error(`[Erudite Resources] Required ${type} panel elements are missing.`);
      return;
    }

    states[type] = {
      panel, groups, counts, searchForm, searchInput, searchClear, searchHint,
      searchTerm: '', loaded: false, loading: false, data: [], error: null
    };
  }

  async function requestJson(url) {
    const response = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      headers: { Accept: 'application/json' },
      cache: 'no-store'
    });

    const raw = await response.text();
    let payload = null;
    try {
      payload = raw ? JSON.parse(raw) : null;
    } catch (_) {
      payload = null;
    }

    if (!response.ok) {
      const reason = payload?.message || payload?.error || `Request failed (${response.status}).`;
      const code = payload?.code ? ` [${payload.code}]` : '';
      throw new Error(`${reason}${code}`);
    }

    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      throw new Error('The ResourceManager endpoint did not return a JSON object.');
    }

    if (payload.success !== true) {
      throw new Error(payload.message || 'The ResourceManager request was not successful.');
    }

    return payload;
  }

  function asArray(value) {
    // The response schema always contains data. If an older response omits it,
    // treat it as zero rows while still rendering the table structure.
    return Array.isArray(value) ? value : [];
  }

  async function loadSectionCatalogue() {
    if (sectionState.loaded) return sectionState.data;
    if (sectionState.promise) return sectionState.promise;

    sectionState.promise = (async () => {
      const payload = await requestJson(SECTION_ENDPOINT);
      if (payload.table !== 'resource_sections') {
        throw new Error(`Unexpected section table: ${String(payload.table || 'missing')}. Expected resource_sections.`);
      }

      const sections = asArray(payload.data)
        .map((entry) => ({
          section: String(entry?.section ?? '').trim(),
          section_description: String(entry?.section_description ?? '').trim()
        }))
        .filter((entry) => entry.section)
        .sort((a, b) => a.section.localeCompare(b.section, undefined, {
          sensitivity: 'base', numeric: true
        }));

      sectionState.data = sections;
      sectionState.loaded = true;
      return sections;
    })();

    try {
      return await sectionState.promise;
    } catch (error) {
      sectionState.promise = null;
      throw error;
    }
  }

  async function loadOneSection(section, type) {
    const config = typeConfig[type];
    const key = `${config.table}::${section}`;
    if (resourceCache.has(key)) return resourceCache.get(key);

    const payload = await requestJson(config.endpoint(section));

    if (payload.table !== config.table) {
      throw new Error(`Expected ${config.table} for ${section}, received ${String(payload.table || 'missing')}.`);
    }

    if (String(payload.section ?? '').toLocaleLowerCase() !== section.toLocaleLowerCase()) {
      throw new Error(`Section mismatch for ${section}.`);
    }

    const rows = asArray(payload.data);
    const catalogueEntry = sectionState.data.find(
      (item) => item.section.toLocaleLowerCase() === section.toLocaleLowerCase()
    );

    const result = {
      section: String(payload.section || section),
      section_description: String(payload.section_description ?? catalogueEntry?.section_description ?? ''),
      table: config.table,
      count: Number.isFinite(Number(payload.count)) ? Number(payload.count) : rows.length,
      items: rows
    };

    resourceCache.set(key, result);
    return result;
  }

  async function loadAllSectionsForType(type) {
    const sections = await loadSectionCatalogue();
    if (!sections.length) return [];

    // Fetch only the currently selected table. allSettled ensures a failure in
    // one section does not prevent the remaining section boxes from rendering.
    const requests = await Promise.allSettled(
      sections.map((entry) => loadOneSection(entry.section, type))
    );

    return sections.map((section, index) => {
      const outcome = requests[index];
      if (outcome.status === 'fulfilled') return outcome.value;

      console.error(
        `[Erudite Resources] Failed to load ${typeConfig[type].table} section ${section.section}:`,
        outcome.reason
      );

      return {
        section: section.section,
        section_description: section.section_description,
        table: typeConfig[type].table,
        count: 0,
        items: [],
        error: outcome.reason instanceof Error ? outcome.reason.message : 'This section could not be loaded.'
      };
    });
  }

  function makeTextCell(value, className = '') {
    const cell = document.createElement('td');
    if (className) cell.className = className;
    const text = String(value ?? '').trim();
    cell.textContent = text || '—';
    return cell;
  }

  function safeYouTubeUrl(value) {
    try {
      const url = new URL(String(value || ''));
      const hosts = new Set([
        'youtube.com', 'www.youtube.com', 'm.youtube.com',
        'youtu.be', 'www.youtu.be', 'youtube-nocookie.com', 'www.youtube-nocookie.com'
      ]);
      return ['http:', 'https:'].includes(url.protocol) && hosts.has(url.hostname.toLowerCase())
        ? url.href : null;
    } catch (_) {
      return null;
    }
  }

  function safeDocumentUrl(value) {
    if (!value) return null;
    try {
      // Resolve relative paths against the configured Laravel API base.
      const url = new URL(String(value), `${API_URL.href.replace(/\/+$/, '')}/`);
      if (!['http:', 'https:'].includes(url.protocol)) return null;

      const apiHost = API_URL.hostname.toLowerCase();
      const candidateHost = url.hostname.toLowerCase();
      const localHosts = new Set(['localhost', '127.0.0.1', '::1']);
      const sameHost = candidateHost === apiHost;
      const bothLocal = localHosts.has(candidateHost) && localHosts.has(apiHost);
      if (!sameHost && !bothLocal) return null;

      // Laravel's route() helper may generate the download URL using APP_URL,
      // whose port can differ from the configured API port. Keep the trusted
      // route path but send it to the configured backend origin.
      return new URL(`${url.pathname}${url.search}`, API_URL.origin).href;
    } catch (_) {
      return null;
    }
  }

  function formatDate(value) {
    if (!value) return '—';
    const date = new Date(String(value).replace(' ', 'T'));
    if (Number.isNaN(date.getTime())) return String(value);
    return new Intl.DateTimeFormat('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric'
    }).format(date);
  }

  function setPanelMessage(type, message, isError = false) {
    const state = states[type];
    const element = document.createElement('div');
    element.className = `resource-state${isError ? ' is-error' : ''}`;
    element.textContent = message;
    state.groups.replaceChildren(element);
    state.groups.setAttribute('aria-busy', 'false');
  }

  function appendEmptyRow(tbody, columnCount, message, className = 'resource-empty-row') {
    const row = document.createElement('tr');
    row.className = className;
    const cell = document.createElement('td');
    cell.className = 'resource-table-empty';
    cell.colSpan = columnCount;
    cell.textContent = message;
    row.append(cell);
    tbody.append(row);
  }

  function createActionCell(item, type) {
    const cell = document.createElement('td');
    cell.className = 'resource-action-cell';

    if (type === 'videos') {
      const href = safeYouTubeUrl(item?.youtube_link);
      if (!href) {
        cell.textContent = 'Video link unavailable';
        cell.classList.add('is-unavailable');
        return cell;
      }

      const link = document.createElement('a');
      link.href = href;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = '▶ Open YouTube video ↗';
      cell.append(link);
      return cell;
    }

    const hasDocument = item?.has_document === true || Number(item?.has_document) === 1;
    const href = hasDocument ? safeDocumentUrl(item?.download_url) : null;
    if (!hasDocument) {
      cell.textContent = 'No file uploaded';
      cell.classList.add('is-unavailable');
      return cell;
    }
    if (!href) {
      cell.textContent = 'Download URL unavailable';
      cell.classList.add('is-unavailable');
      return cell;
    }

    const link = document.createElement('a');
    link.href = href;
    link.textContent = '↓ Download document';
    link.setAttribute('download', '');
    link.rel = 'noopener noreferrer';
    cell.append(link);
    return cell;
  }

  function createSectionCard(sectionData, index, type) {
    const config = typeConfig[type];
    const card = document.createElement('article');
    card.className = 'resource-section-card';
    card.dataset.sectionSearch = [sectionData.section, sectionData.section_description]
      .join(' ').toLocaleLowerCase();

    const header = document.createElement('header');
    header.className = 'resource-section-header';

    const heading = document.createElement('div');
    heading.className = 'resource-section-heading';

    const kicker = document.createElement('p');
    kicker.className = 'resource-section-kicker';
    kicker.textContent = `SECTION ${String(index + 1).padStart(2, '0')}`;

    const title = document.createElement('h3');
    title.textContent = sectionData.section;

    const description = document.createElement('p');
    description.className = 'resource-section-description';
    description.textContent = sectionData.section_description || ' ';

    heading.append(kicker, title, description);

    const count = document.createElement('p');
    count.className = 'resource-section-count';
    count.textContent = `${sectionData.items.length} ${config.itemLabel}${sectionData.items.length === 1 ? '' : 's'}`;
    header.append(heading, count);

    const tableWrap = document.createElement('div');
    tableWrap.className = 'resource-table-wrap';

    const table = document.createElement('table');
    table.className = 'resource-table';

    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    config.columns.forEach((label) => {
      const th = document.createElement('th');
      th.scope = 'col';
      th.textContent = label;
      headerRow.append(th);
    });
    thead.append(headerRow);

    const tbody = document.createElement('tbody');

    if (sectionData.error) {
      appendEmptyRow(tbody, config.columns.length, `Could not load this section: ${sectionData.error}`, 'resource-error-row');
    } else if (!sectionData.items.length) {
      appendEmptyRow(tbody, config.columns.length, config.emptyMessage);
    } else {
      sectionData.items.forEach((item) => {
        const row = document.createElement('tr');
        row.append(
          makeTextCell(item?.id, 'resource-id-cell'),
          makeTextCell(item?.title, 'resource-title-cell'),
          makeTextCell(item?.title_description, 'resource-description-cell'),
          createActionCell(item, type),
          makeTextCell(formatDate(item?.created_at), 'resource-updated-cell'),
          makeTextCell(formatDate(item?.updated_at), 'resource-updated-cell')
        );
        row.dataset.searchText = [
          sectionData.section,
          sectionData.section_description,
          item?.title,
          item?.title_description,
          type === 'videos' ? item?.youtube_link : item?.id
        ].join(' ').toLocaleLowerCase();
        tbody.append(row);
      });
    }

    table.append(thead, tbody);
    tableWrap.append(table);
    card.append(header, tableWrap);
    return card;
  }

  function applySearch(type) {
    const state = states[type];
    const query = state.searchTerm.trim().toLocaleLowerCase();
    const cards = [...state.groups.querySelectorAll('.resource-section-card')];
    let visibleSections = 0;
    let visibleRows = 0;

    cards.forEach((card) => {
      const matchesSection = !query || card.dataset.sectionSearch.includes(query);
      const rows = [...card.querySelectorAll('tbody tr')];
      let matchingRows = 0;

      rows.forEach((row) => {
        const isMessageRow = row.classList.contains('resource-empty-row') || row.classList.contains('resource-error-row');
        let visible;
        if (!query) {
          visible = true;
        } else if (isMessageRow) {
          visible = matchesSection;
        } else {
          visible = matchesSection || (row.dataset.searchText || '').includes(query);
        }

        row.hidden = !visible;
        if (visible && !isMessageRow) matchingRows += 1;
      });

      // A section-name match keeps the whole section table visible, including
      // its empty-state row. A resource match keeps only matching resource rows.
      const cardVisible = !query || matchesSection || matchingRows > 0;
      card.hidden = !cardVisible;
      if (cardVisible) visibleSections += 1;
      visibleRows += matchingRows;
    });

    state.groups.querySelector('.resource-no-results')?.remove();
    if (query && visibleSections === 0) {
      const message = document.createElement('div');
      message.className = 'resource-state resource-no-results';
      message.textContent = `No matching ${typeConfig[type].itemLabel} sections or records found.`;
      state.groups.append(message);
    }

    state.searchHint.textContent = query
      ? `${visibleSections} matching ${visibleSections === 1 ? 'section' : 'sections'} · ${visibleRows} matching ${typeConfig[type].itemLabel}${visibleRows === 1 ? '' : 's'}`
      : `Search ${typeConfig[type].itemLabel} sections, titles or descriptions.`;
    state.searchClear.hidden = !query;
  }

  function renderType(type) {
    const state = states[type];
    const config = typeConfig[type];
    state.groups.replaceChildren();

    if (!sectionState.data.length) {
      setPanelMessage(type, 'No resource sections are available yet.');
      state.counts.textContent = '0 sections';
      return;
    }

    // A section card is rendered for every section discovered across both
    // resource tables, even when this selected table has data: [].
    state.data.forEach((section, index) => {
      state.groups.append(createSectionCard(section, index, type));
    });

    const recordCount = state.data.reduce((sum, section) => sum + section.items.length, 0);
    state.counts.textContent = `${state.data.length} ${state.data.length === 1 ? 'section' : 'sections'} · ${recordCount} ${config.itemLabel}${recordCount === 1 ? '' : 's'}`;
    state.groups.setAttribute('aria-busy', 'false');
    applySearch(type);
  }

  async function loadType(type) {
    const state = states[type];
    if (state.loaded) {
      renderType(type);
      return;
    }
    if (state.loading) return;

    state.loading = true;
    state.counts.textContent = 'Loading sections…';
    state.groups.setAttribute('aria-busy', 'true');
    setPanelMessage(type, typeConfig[type].loadMessage);

    try {
      // Only this type's endpoint is called for every discovered section.
      state.data = await loadAllSectionsForType(type);
      state.loaded = true;
      state.error = null;
      renderType(type);
    } catch (error) {
      state.error = error;
      console.error(`[Erudite Resources] ${typeConfig[type].table} failed:`, error);
      state.counts.textContent = 'Resources unavailable';
      setPanelMessage(type, error.message || `${typeConfig[type].title} could not be loaded.`, true);
    } finally {
      state.loading = false;
    }
  }

  function showType(type) {
    if (!states[type]) return;
    for (const [candidate, state] of Object.entries(states)) {
      state.panel.hidden = candidate !== type;
    }

    typeButtons.forEach((button) => {
      const active = button.dataset.resourceType === type;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });

    loadType(type);
  }

  // Each search module owns its own form, input, clear button and query state.
  for (const [type, state] of Object.entries(states)) {
    state.searchForm.addEventListener('submit', (event) => {
      event.preventDefault();
      state.searchTerm = state.searchInput.value;
      if (state.loaded) applySearch(type);
    });

    state.searchInput.addEventListener('input', () => {
      state.searchTerm = state.searchInput.value;
      if (state.loaded) applySearch(type);
    });

    state.searchClear.addEventListener('click', () => {
      state.searchInput.value = '';
      state.searchTerm = '';
      if (state.loaded) applySearch(type);
      state.searchInput.focus();
    });
  }

  typeButtons.forEach((button) => {
    button.addEventListener('click', () => showType(button.dataset.resourceType));
  });

  // Start with Video Resources. Documents are not requested until selected.
  showType('videos');
})();
