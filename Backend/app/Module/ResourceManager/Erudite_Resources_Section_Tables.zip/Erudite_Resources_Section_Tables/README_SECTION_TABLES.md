# Erudite resource section tables — frontend implementation

## Desired behaviour

- The shared `GET /api/resources/sections` response creates the list of section boxes. It is sourced from the union of `video_resources.section` and `document_resources.section`.
- Clicking **Video Resources** calls only `GET /api/resources/video-resources/{section}` for each discovered section. It does not call the document endpoint.
- Clicking **Document Resources** calls only `GET /api/resources/document-resources/{section}` for each discovered section. It does not call the video endpoint.
- Each discovered section always gets a card/table in the selected module, including when the response has `count: 0` and `data: []` (or if `data` is omitted). In that case the column headings remain visible and an empty-state message is shown in the table body.
- Video and document search forms, inputs and search state are independent.
- A failed request for one section shows an error row in that section's table but does not suppress the other section cards.

## Files

Copy the files into `Eruweb/erudite_homepage/`:

- `resources.html`
- `resources.js`
- `resource-config.js`
- `style.css`

The HTML retains the current Resources page layout; the CSS is included unchanged from the previous resource frontend package. `resources.js` contains the section-card and table rendering behaviour.

## API base

`resource-config.js` currently targets:

```js
window.ERUDITE_RESOURCE_API_BASE = 'http://127.0.0.1:8012/api';
```

Change this one value when your Laravel API host or port changes.

## JSON contract

Sections response:

```json
{
  "success": true,
  "table": "resource_sections",
  "source_tables": ["video_resources", "document_resources"],
  "count": 2,
  "data": [
    {"section": "QUANT", "section_description": ""},
    {"section": "Varc", "section_description": ""}
  ]
}
```

Video response per section:

```json
{
  "success": true,
  "table": "video_resources",
  "section": "QUANT",
  "section_description": "",
  "count": 0,
  "data": []
}
```

Document response per section:

```json
{
  "success": true,
  "table": "document_resources",
  "section": "QUANT",
  "section_description": "",
  "count": 0,
  "data": []
}
```

Document listing rows include `has_document` and `download_url`. The BLOB itself is fetched from the separate download endpoint. If Laravel's `route()` helper creates an absolute download URL using an APP_URL port different from the configured API port, the frontend preserves the trusted path and re-targets it to the configured backend origin. It rejects external hosts.

## Notes

- This package does not change backend PHP files or database tables.
- It does not remove or bypass `RiskCheckMiddleware`.
- Cross-origin requests send credentials via `credentials: 'include'`; Laravel CORS/session configuration still needs to allow the frontend origin.
